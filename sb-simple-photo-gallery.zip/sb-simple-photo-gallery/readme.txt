=== SB Simple Photo Gallery Block for Gutenberg ===
Contributors: souravws
Donate link: https://buy.stripe.com/3csaEG5BieBLdeUaEG
Tags: gallery, photo gallery, masonry, justified, gutenberg
Requires at least: 6.0
Tested up to: 6.9
Stable tag: 3.1.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A responsive photo gallery block for Gutenberg with Grid, Masonry, Justified & Mosaic layouts plus a built-in lightbox.

== Description ==

SB Simple Photo Gallery adds a powerful yet easy-to-use photo gallery block to the WordPress Gutenberg editor. Select your images from the Media Library and display them in four stunning layout styles — all without writing a single line of code.

**Layout Styles**

* **Grid** — Clean, equal-height responsive grid
* **Masonry** — Pinterest-style columns that respect each image's natural proportions
* **Justified** — Google Photos-style rows where every image shares the same height and fills the full width
* **Mosaic** — Featured-image layout with a large hero photo and supporting thumbnails

**Features**

* Built-in lightbox with smooth prev/next navigation
* Caption support — overlay on hover or below each image
* Adjustable columns (1–6), gap, image height, and border radius
* Wide and full-width block alignment support
* Full keyboard navigation (Arrow keys and Escape)
* Lazy loading for better page performance
* No jQuery — lightweight vanilla JavaScript only
* No external libraries or third-party dependencies
* Translation-ready with full i18n support

**How It Works**

1. Install and activate the plugin.
2. Open any post or page in the Gutenberg editor.
3. Click the block inserter (+) and search for **SB Simple Photo Gallery**.
4. Select your images from the WordPress Media Library.
5. Choose a layout and adjust settings in the Block sidebar.
6. Save and publish.

== Installation ==

**From the WordPress Plugin Directory (recommended)**

1. Go to **Plugins > Add New** in your WordPress admin.
2. Search for **SB Simple Photo Gallery**.
3. Click **Install Now**, then **Activate**.

**Manual Installation**

1. Download the plugin zip file.
2. Go to **Plugins > Add New > Upload Plugin**.
3. Upload the zip file and click **Install Now**.
4. Activate the plugin from the Plugins page.

**From Source**

1. Upload the `sb-simple-photo-gallery` folder to `/wp-content/plugins/`.
2. Activate the plugin through the **Plugins** menu in WordPress.

== Frequently Asked Questions ==

= Which WordPress version is required? =

WordPress 6.0 or higher is required. The plugin is built on modern Gutenberg block APIs.

= Does it work with my theme? =

Yes. The plugin outputs standard semantic HTML and scoped CSS. It has been tested with Twenty Twenty-Four and Twenty Twenty-Five. It should work with any well-coded WordPress theme.

= Does it work with the Classic Editor? =

No. This is a Gutenberg (Block Editor) plugin. The Classic Editor is not supported.

= Does the lightbox work on mobile devices? =

Yes. The lightbox supports touch swipe gestures to move between images on mobile and tablet devices.

= Why does the Masonry layout briefly appear as a simple column layout? =

The Masonry layout uses JavaScript to calculate and position items based on each image's actual dimensions. On first load, a CSS-columns fallback displays while JavaScript initialises. Once images are loaded the layout corrects itself. This is expected behaviour.

= Can I show image captions? =

Yes. Enable "Show Captions" in the block sidebar and choose between an overlay style (captions appear on hover) or a below-image style.

= Is the plugin translation-ready? =

Yes. All user-facing strings use WordPress i18n functions (`__()`) with the `sb-simple-photo-gallery` text domain.

= Will it slow down my website? =

No. Images use the browser-native `loading="lazy"` attribute. The frontend JavaScript is only loaded on pages that contain a gallery block. There are no external HTTP requests, no third-party fonts, and no tracking of any kind.

== Screenshots ==

1. The gallery block in the Gutenberg editor with the visual layout picker and sidebar controls.
2. Grid layout — clean equal-height responsive grid on the frontend.
3. Masonry layout — Pinterest-style columns with natural image proportions.
4. Justified layout — rows where all images share the same height and fill the full width.
5. Mosaic layout — featured hero image with supporting thumbnails.
6. Built-in lightbox with image counter, caption, and prev/next navigation.

== Changelog ==

= 3.1.0 =
* Fixed Masonry layout — now uses actual image dimensions for correct aspect ratios and re-layouts after images load
* Fixed Mosaic layout — images now correctly fill their grid cells at all sizes
* Fixed Justified layout — images correctly fill their JS-calculated row heights
* Set Masonry as the default layout for new gallery blocks
* Removed Carousel layout (will return in a future release once stabilised)

= 3.0.0 =
* Added Masonry, Justified, and Mosaic layout styles
* Added visual layout picker in the block sidebar with SVG preview icons
* Added lightbox with smooth animation, keyboard navigation, image counter, and captions
* Added ResizeObserver-based responsive relayout for Masonry and Justified
* Frontend JavaScript rewritten as a single unified file (no jQuery)
* Touch swipe support for lightbox on mobile

= 2.0.0 =
* Added lightbox with prev/next navigation
* Added caption overlay style (hover reveal)
* Added gap, image height, and border radius controls in the sidebar
* Added wide and full-width block alignment support

= 1.0.0 =
* Initial release — responsive grid gallery Gutenberg block

== Upgrade Notice ==

= 3.1.0 =
Bug-fix release. Masonry, Mosaic, and Justified layouts now display correctly. Masonry is now the default layout for new galleries.

<?php
/**
 * Plugin Name:       SB Simple Photo Gallery
 * Description:       Responsive photo gallery block for Gutenberg with Grid, Masonry, Justified & Mosaic layouts plus a built-in lightbox.
 * Version:           3.1.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Sourav Biswas
 * Author URI:        https://sourav.work/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       sb-simple-photo-gallery
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function spg_register_block() {
	wp_register_script(
		'spg-block-editor',
		plugins_url( 'assets/block.js', __FILE__ ),
		[ 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-i18n' ],
		filemtime( plugin_dir_path( __FILE__ ) . 'assets/block.js' ),
		false
	);

	wp_register_script(
		'spg-frontend',
		plugins_url( 'assets/frontend.js', __FILE__ ),
		[],
		filemtime( plugin_dir_path( __FILE__ ) . 'assets/frontend.js' ),
		true
	);

	wp_register_style(
		'spg-editor-style',
		plugins_url( 'assets/editor.css', __FILE__ ),
		[ 'wp-edit-blocks' ],
		filemtime( plugin_dir_path( __FILE__ ) . 'assets/editor.css' )
	);

	wp_register_style(
		'spg-style',
		plugins_url( 'assets/style.css', __FILE__ ),
		[],
		filemtime( plugin_dir_path( __FILE__ ) . 'assets/style.css' )
	);

	register_block_type( 'simple-gallery/photo-gallery', [
		'editor_script'   => 'spg-block-editor',
		'editor_style'    => 'spg-editor-style',
		'style'           => 'spg-style',
		'view_script'     => 'spg-frontend',
		'render_callback' => 'spg_render_block',
		'attributes'      => [
			'images' => [
				'type'    => 'array',
				'default' => [],
				'items'   => [
					'type'       => 'object',
					'properties' => [
						'id'      => [ 'type' => 'integer' ],
						'url'     => [ 'type' => 'string'  ],
						'fullUrl' => [ 'type' => 'string'  ],
						'alt'     => [ 'type' => 'string'  ],
						'caption' => [ 'type' => 'string'  ],
						'width'   => [ 'type' => 'number'  ],
						'height'  => [ 'type' => 'number'  ],
					],
				],
			],
			'layout'          => [ 'type' => 'string',  'default' => 'masonry' ],
			'columns'         => [ 'type' => 'number',  'default' => 3         ],
			'gap'             => [ 'type' => 'number',  'default' => 12        ],
			'imageHeight'     => [ 'type' => 'number',  'default' => 260       ],
			'borderRadius'    => [ 'type' => 'number',  'default' => 6         ],
			'captionStyle'    => [ 'type' => 'string',  'default' => 'overlay' ],
			'showCaptions'    => [ 'type' => 'boolean', 'default' => true      ],
			'lightbox'        => [ 'type' => 'boolean', 'default' => true      ],
			'justifiedHeight' => [ 'type' => 'number',  'default' => 220       ],
		],
	] );
}
add_action( 'init', 'spg_register_block' );

function spg_render_block( $attributes ) {
	$images           = $attributes['images']          ?? [];
	$layout           = sanitize_key( $attributes['layout']          ?? 'grid' );
	$columns          = intval( $attributes['columns']        ?? 3   );
	$gap              = intval( $attributes['gap']             ?? 12  );
	$image_height     = intval( $attributes['imageHeight']     ?? 260 );
	$border_radius    = intval( $attributes['borderRadius']    ?? 6   );
	$caption_style    = sanitize_text_field( $attributes['captionStyle'] ?? 'overlay' );
	$show_captions    = ! empty( $attributes['showCaptions'] );
	$lightbox         = ! empty( $attributes['lightbox'] );
	$justified_height = intval( $attributes['justifiedHeight'] ?? 220 );

	if ( empty( $images ) ) {
		return '';
	}

	$allowed = [ 'grid', 'masonry', 'justified', 'mosaic' ];
	if ( ! in_array( $layout, $allowed, true ) ) {
		$layout = 'grid';
	}

	$css_vars = implode( ';', [
		'--spg-columns:' . $columns,
		'--spg-gap:'     . $gap . 'px',
		'--spg-height:'  . $image_height . 'px',
		'--spg-radius:'  . $border_radius . 'px',
	] );

	$data = ' data-layout="' . esc_attr( $layout ) . '"';
	if ( $lightbox )               $data .= ' data-lightbox="1"';
	if ( $layout === 'justified' ) $data .= ' data-jh="' . esc_attr( $justified_height ) . '"';

	$html  = '<div class="spg-gallery spg-gallery--' . esc_attr( $layout ) . '" style="' . esc_attr( $css_vars ) . '"' . $data . '>';
	$html .= '<div class="spg-gallery__inner">';

	foreach ( $images as $image ) {
		$url      = esc_url( $image['url']      ?? '' );
		$full_url = esc_url( $image['fullUrl']  ?? $url );
		$alt      = esc_attr( $image['alt']     ?? '' );
		$caption  = wp_kses_post( $image['caption'] ?? '' );
		$w        = intval( $image['width']  ?? 0 );
		$h        = intval( $image['height'] ?? 0 );
		$ar       = ( $h > 0 ) ? round( $w / $h, 4 ) : 1.5;

		if ( ! $url ) {
			continue;
		}

		$html .= '<figure class="spg-gallery-item" data-ar="' . esc_attr( $ar ) . '">';
		$html .= '<a href="' . $full_url . '" class="spg-gallery-link">';
		$html .= '<img src="' . $url . '" alt="' . $alt . '" loading="lazy">';

		if ( $show_captions && $caption && $caption_style === 'overlay' ) {
			$html .= '<figcaption class="spg-caption spg-caption--overlay">' . $caption . '</figcaption>';
		}

		$html .= '</a>';

		if ( $show_captions && $caption && $caption_style === 'below' ) {
			$html .= '<figcaption class="spg-caption spg-caption--below">' . $caption . '</figcaption>';
		}

		$html .= '</figure>';
	}

	$html .= '</div>'; // .spg-gallery__inner
	$html .= '</div>'; // .spg-gallery

	return $html;
}

(function () {
	var el                = wp.element.createElement;
	var Fragment          = wp.element.Fragment;
	var __                = wp.i18n.__;
	var registerBlockType = wp.blocks.registerBlockType;
	var useBlockProps     = wp.blockEditor.useBlockProps;
	var MediaUpload       = wp.blockEditor.MediaUpload;
	var MediaUploadCheck  = wp.blockEditor.MediaUploadCheck;
	var InspectorControls = wp.blockEditor.InspectorControls;
	var PanelBody         = wp.components.PanelBody;
	var RangeControl      = wp.components.RangeControl;
	var ToggleControl     = wp.components.ToggleControl;
	var SelectControl     = wp.components.SelectControl;
	var Button = wp.components.Button;

	/* ── Layout icons (inline SVG strings) ──────────────────── */
	var ICONS = {
		grid:      '<svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><rect x="2" y="2" width="9" height="9" rx="1.5"/><rect x="13" y="2" width="9" height="9" rx="1.5"/><rect x="2" y="13" width="9" height="9" rx="1.5"/><rect x="13" y="13" width="9" height="9" rx="1.5"/></svg>',
		masonry:   '<svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><rect x="2" y="2" width="9" height="15" rx="1.5"/><rect x="13" y="2" width="9" height="8" rx="1.5"/><rect x="13" y="12" width="9" height="10" rx="1.5"/><rect x="2" y="19" width="9" height="3" rx="1.5"/></svg>',
		justified: '<svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><rect x="2" y="2" width="7" height="9" rx="1.5"/><rect x="11" y="2" width="5" height="9" rx="1.5"/><rect x="18" y="2" width="4" height="9" rx="1.5"/><rect x="2" y="13" width="5" height="9" rx="1.5"/><rect x="9" y="13" width="8" height="9" rx="1.5"/><rect x="19" y="13" width="3" height="9" rx="1.5"/></svg>',
		mosaic:    '<svg viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg"><rect x="2" y="2" width="13" height="13" rx="1.5"/><rect x="17" y="2" width="5" height="5" rx="1.5"/><rect x="17" y="9" width="5" height="6" rx="1.5"/><rect x="2" y="17" width="5" height="5" rx="1.5"/><rect x="9" y="17" width="5" height="5" rx="1.5"/><rect x="16" y="17" width="6" height="5" rx="1.5"/></svg>',
	};

	var LAYOUTS = [
		{ key: 'grid',      label: 'Grid'      },
		{ key: 'masonry',   label: 'Masonry'   },
		{ key: 'justified', label: 'Justified' },
		{ key: 'mosaic',    label: 'Mosaic'    },
	];

	/* ── Layout picker component ─────────────────────────────── */
	function LayoutPicker( props ) {
		return el( 'div', { className: 'spg-layout-picker' },
			LAYOUTS.map( function ( opt ) {
				return el( 'button', {
					key:           opt.key,
					type:          'button',
					title:         opt.label,
					className:     'spg-layout-btn' + ( props.value === opt.key ? ' is-active' : '' ),
					onClick:       function () { props.onChange( opt.key ); },
					'aria-pressed': props.value === opt.key,
				},
					el( 'span', {
						className:               'spg-layout-icon',
						dangerouslySetInnerHTML: { __html: ICONS[ opt.key ] },
					} ),
					el( 'span', { className: 'spg-layout-label' }, opt.label )
				);
			} )
		);
	}

	/* ── Block registration ──────────────────────────────────── */
	registerBlockType( 'simple-gallery/photo-gallery', {
		title:       __( 'SB Simple Photo Gallery', 'sb-simple-photo-gallery' ),
		icon:        'format-gallery',
		category:    'media',
		description: __( 'SB responsive gallery — Grid, Masonry, Justified & Mosaic layouts with built-in lightbox.', 'sb-simple-photo-gallery' ),
		supports: { align: [ 'wide', 'full' ], html: false },

		edit: function ( props ) {
			var attr = props.attributes;
			var set  = props.setAttributes;

			var images        = attr.images        || [];
			var layout        = attr.layout        || 'masonry';
			var columns       = attr.columns       || 3;
			var gap           = attr.gap           != null ? attr.gap : 12;
			var imageHeight   = attr.imageHeight   || 260;
			var borderRadius  = attr.borderRadius  != null ? attr.borderRadius : 6;
			var captionStyle  = attr.captionStyle  || 'overlay';
			var showCaptions  = attr.showCaptions  !== false;
			var lightbox      = attr.lightbox      !== false;
			var justifiedHeight = attr.justifiedHeight || 220;
			var blockProps = useBlockProps();

			/* Image selection */
			function onSelect( selected ) {
				set({
					images: selected.map( function ( img ) {
						return {
							id:      img.id,
							url:     ( img.sizes && img.sizes.large )
								? img.sizes.large.url
								: ( img.sizes && img.sizes.medium_large )
									? img.sizes.medium_large.url
									: img.url,
							fullUrl: img.url,
							alt:     img.alt     || '',
							caption: img.caption || '',
							width:   img.width   || 0,
							height:  img.height  || 0,
						};
					} ),
				});
			}

			function removeImage( index ) {
				set({ images: images.filter( function ( _, i ) { return i !== index; } ) });
			}

			/* ── Inspector sidebar ───────────────────────────── */
			var inspector = el( InspectorControls, null,

				/* Layout picker */
				el( PanelBody, { title: __( 'Layout Style', 'sb-simple-photo-gallery' ), initialOpen: true },
					el( LayoutPicker, { value: layout, onChange: function ( v ) { set({ layout: v }); } } )
				),

				/* Layout options (conditional) */
				el( PanelBody, { title: __( 'Layout Options', 'sb-simple-photo-gallery' ), initialOpen: true },

					el( RangeControl, {
						label:    __( 'Columns', 'sb-simple-photo-gallery' ),
						value:    columns,
						onChange: function ( v ) { set({ columns: v }); },
						min: 1, max: 6,
					} ),

					el( RangeControl, {
						label:    __( 'Gap (px)', 'sb-simple-photo-gallery' ),
						value:    gap,
						onChange: function ( v ) { set({ gap: v }); },
						min: 0, max: 48,
					} ),

					layout !== 'masonry' && layout !== 'justified' && el( RangeControl, {
						label:    __( 'Image Height (px)', 'sb-simple-photo-gallery' ),
						value:    imageHeight,
						onChange: function ( v ) { set({ imageHeight: v }); },
						min: 80, max: 600,
					} ),

					layout === 'justified' && el( RangeControl, {
						label:    __( 'Row Height (px)', 'sb-simple-photo-gallery' ),
						value:    justifiedHeight,
						onChange: function ( v ) { set({ justifiedHeight: v }); },
						min: 80, max: 500,
					} ),

					el( RangeControl, {
						label:    __( 'Border Radius (px)', 'sb-simple-photo-gallery' ),
						value:    borderRadius,
						onChange: function ( v ) { set({ borderRadius: v }); },
						min: 0, max: 32,
					} )
				),

				/* Captions & lightbox */
				el( PanelBody, { title: __( 'Captions & Lightbox', 'sb-simple-photo-gallery' ), initialOpen: false },
					el( ToggleControl, {
						label:    __( 'Show Captions', 'sb-simple-photo-gallery' ),
						checked:  showCaptions,
						onChange: function ( v ) { set({ showCaptions: v }); },
					} ),
					showCaptions && el( SelectControl, {
						label:    __( 'Caption Style', 'sb-simple-photo-gallery' ),
						value:    captionStyle,
						onChange: function ( v ) { set({ captionStyle: v }); },
						options: [
							{ label: __( 'Overlay on hover', 'sb-simple-photo-gallery' ), value: 'overlay' },
							{ label: __( 'Below image',      'sb-simple-photo-gallery' ), value: 'below'   },
						],
					} ),
					el( ToggleControl, {
						label:    __( 'Enable Lightbox', 'sb-simple-photo-gallery' ),
						help:     __( 'Click to view full image with navigation.', 'sb-simple-photo-gallery' ),
						checked:  lightbox,
						onChange: function ( v ) { set({ lightbox: v }); },
					} )
				)
			);

			/* ── CSS vars for editor preview ─────────────────── */
			var cssVars = {
				'--spg-columns': columns,
				'--spg-gap':     gap + 'px',
				'--spg-height':  imageHeight + 'px',
				'--spg-radius':  borderRadius + 'px',
			};

			/* ── Render a single gallery item ────────────────── */
			function renderItem( img, index, opts ) {
				opts = opts || {};
				return el( 'figure', {
					key:       img.id || index,
					className: 'spg-gallery-item',
					style:     opts.itemStyle || {},
				},
					el( 'img', { src: img.url, alt: img.alt } ),
					! opts.noRemove && el( 'button', {
						type:         'button',
						className:    'spg-remove-btn',
						onClick:      function () { removeImage( index ); },
						'aria-label': __( 'Remove', 'sb-simple-photo-gallery' ),
					}, '×' ),
					showCaptions && img.caption
						? el( 'figcaption', { className: 'spg-caption spg-caption--' + captionStyle }, img.caption )
						: null
				);
			}

			/* ── Layout-specific editor grid ─────────────────── */
			function renderGrid() {
				return el( 'div', {
					className: 'spg-gallery-grid spg-gallery-grid--' + layout,
					style:     cssVars,
				}, images.map( function ( img, i ) { return renderItem( img, i ); } ) );
			}

			/* ── Placeholder ─────────────────────────────────── */
			var placeholder = el( 'div', { className: 'spg-placeholder' },
				el( 'span', { className: 'dashicons dashicons-format-gallery' } ),
				el( 'p', null, __( 'No images yet. Click below to add.', 'sb-simple-photo-gallery' ) )
			);

			/* ── Toolbar row ─────────────────────────────────── */
			var toolbar = el( 'div', { className: 'spg-toolbar' },
				el( MediaUploadCheck, null,
					el( MediaUpload, {
						onSelect:     onSelect,
						allowedTypes: [ 'image' ],
						multiple:     true,
						gallery:      true,
						value:        images.map( function ( img ) { return img.id; } ),
						render:       function ( ref ) {
							return el( Button, {
								onClick:  ref.open,
								variant:  images.length > 0 ? 'secondary' : 'primary',
								icon:     'format-gallery',
							}, images.length > 0
								? __( 'Edit Gallery', 'sb-simple-photo-gallery' ) + ' (' + images.length + ')'
								: __( 'Add Images', 'sb-simple-photo-gallery' )
							);
						},
					} )
				),
				images.length > 0 && el( Button, {
					variant:       'tertiary',
					isDestructive: true,
					onClick:       function () { set({ images: [] }); },
				}, __( 'Clear All', 'sb-simple-photo-gallery' ) )
			);

			return el( Fragment, null,
				inspector,
				el( 'div', blockProps,
					el( 'div', { className: 'spg-gallery-editor' },
						images.length > 0 ? renderGrid() : placeholder,
						toolbar
					)
				)
			);
		},

		save: function () { return null; },
	} );
})();

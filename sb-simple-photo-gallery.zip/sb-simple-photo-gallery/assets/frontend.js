(function () {
	'use strict';

	/* ── Utility ─────────────────────────────────────────────── */
	function debounce( fn, ms ) {
		var t;
		return function () { clearTimeout( t ); t = setTimeout( fn, ms ); };
	}

	function observe( el, fn ) {
		if ( window.ResizeObserver ) {
			new ResizeObserver( fn ).observe( el );
		} else {
			window.addEventListener( 'resize', debounce( fn, 150 ) );
		}
	}

	function cssVar( el, name ) {
		return parseFloat( getComputedStyle( el ).getPropertyValue( name ) ) || 0;
	}

	/* ════════════════════════════════════════════════════════════
	   MASONRY — absolute-position JS masonry (left-to-right fill)
	   ════════════════════════════════════════════════════════════ */
	function initMasonry( gallery ) {
		var inner = gallery.querySelector( '.spg-gallery__inner' );
		var items = Array.from( inner.querySelectorAll( '.spg-gallery-item' ) );

		/* Prefer actual loaded image dimensions; fall back to data-ar */
		function getAR( item ) {
			var img = item.querySelector( 'img' );
			if ( img && img.naturalWidth && img.naturalHeight ) {
				return img.naturalWidth / img.naturalHeight;
			}
			return parseFloat( item.dataset.ar ) || 1.5;
		}

		function layout() {
			var W       = inner.offsetWidth;
			var columns = Math.round( cssVar( gallery, '--spg-columns' ) ) || 3;
			var gap     = cssVar( gallery, '--spg-gap' ) || 12;

			columns = Math.max( 1, Math.min( columns, items.length ) );

			var colW    = ( W - gap * ( columns - 1 ) ) / columns;
			var heights = Array( columns ).fill( 0 );

			/* Switch from CSS-columns fallback to JS absolute layout */
			inner.classList.add( 'spg-masonry-active' );

			items.forEach( function ( item ) {
				var ar  = getAR( item );
				var h   = Math.round( colW / ar );
				var col = heights.indexOf( Math.min.apply( null, heights ) );
				var top = heights[ col ] + ( heights[ col ] > 0 ? gap : 0 );

				item.style.cssText = [
					'position:absolute',
					'width:'  + colW + 'px',
					'height:' + h    + 'px',
					'left:'   + ( col * ( colW + gap ) ) + 'px',
					'top:'    + top  + 'px',
				].join( ';' );

				heights[ col ] = top + h;
			} );

			inner.style.height = Math.max.apply( null, heights ) + 'px';
		}

		/* First pass with stored data-ar values */
		layout();

		/* Second pass once actual image dimensions are available */
		var pending = items.length;
		items.forEach( function ( item ) {
			var img = item.querySelector( 'img' );
			if ( ! img || ( img.complete && img.naturalWidth ) ) {
				if ( --pending <= 0 ) layout();
				return;
			}
			img.addEventListener( 'load', function () {
				if ( --pending <= 0 ) layout();
			}, { once: true } );
		} );

		observe( gallery, layout );
	}

	/* ════════════════════════════════════════════════════════════
	   JUSTIFIED — fill rows to exact container width
	   ════════════════════════════════════════════════════════════ */
	function initJustified( gallery ) {
		var inner  = gallery.querySelector( '.spg-gallery__inner' );
		var items  = Array.from( inner.querySelectorAll( '.spg-gallery-item' ) );
		var target = parseInt( gallery.dataset.jh ) || 220;

		function getAR( item ) {
			var img = item.querySelector( 'img' );
			if ( img && img.naturalWidth && img.naturalHeight ) {
				return img.naturalWidth / img.naturalHeight;
			}
			return parseFloat( item.dataset.ar ) || 1.5;
		}

		function layout() {
			var W   = inner.offsetWidth;
			var gap = cssVar( gallery, '--spg-gap' ) || 12;

			var row = [], arSum = 0;

			function flush( isLast ) {
				if ( ! row.length ) return;
				var totalGap = gap * ( row.length - 1 );
				var rowW     = arSum * target + totalGap;
				var h;

				if ( isLast && rowW < W * 0.75 ) {
					h = target; /* last partial row — don't over-stretch */
				} else {
					h = ( W - totalGap ) / arSum;
				}

				row.forEach( function ( r ) {
					r.item.style.width  = ( h * r.ar ) + 'px';
					r.item.style.height = h + 'px';
				} );

				row = []; arSum = 0;
			}

			items.forEach( function ( item, i ) {
				var ar = getAR( item );
				row.push( { item: item, ar: ar } );
				arSum += ar;

				var rowW = arSum * target + gap * ( row.length - 1 );
				if ( rowW >= W ) { flush( false ); }
				else if ( i === items.length - 1 ) { flush( true ); }
			} );
		}

		layout();

		/* Re-layout with real dimensions once images load */
		var pending = items.length;
		items.forEach( function ( item ) {
			var img = item.querySelector( 'img' );
			if ( ! img || ( img.complete && img.naturalWidth ) ) {
				if ( --pending <= 0 ) layout();
				return;
			}
			img.addEventListener( 'load', function () {
				if ( --pending <= 0 ) layout();
			}, { once: true } );
		} );

		observe( gallery, layout );
	}

	/* ════════════════════════════════════════════════════════════
	   LIGHTBOX — shared across all layout types
	   ════════════════════════════════════════════════════════════ */
	var lb = (function () {
		var overlay, imgEl, captionEl, counterEl, prevBtn, nextBtn;
		var images = [], current = 0, ready = false;

		function build() {
			if ( ready ) return;
			ready = true;

			overlay = document.createElement( 'div' );
			overlay.className = 'spg-lb';
			overlay.setAttribute( 'role', 'dialog' );
			overlay.setAttribute( 'aria-modal', 'true' );

			var backdrop = document.createElement( 'div' );
			backdrop.className = 'spg-lb__backdrop';

			var box = document.createElement( 'div' );
			box.className = 'spg-lb__box';

			function mkbtn( cls, html, label ) {
				var b = document.createElement( 'button' );
				b.className = cls; b.innerHTML = html;
				b.setAttribute( 'aria-label', label );
				return b;
			}

			var closeBtn = mkbtn( 'spg-lb__close', '&times;', 'Close' );
			prevBtn      = mkbtn( 'spg-lb__nav spg-lb__prev', '&#8249;', 'Previous' );
			nextBtn      = mkbtn( 'spg-lb__nav spg-lb__next', '&#8250;', 'Next' );

			imgEl     = document.createElement( 'img' );
			imgEl.className = 'spg-lb__img';
			captionEl = document.createElement( 'p' );
			captionEl.className = 'spg-lb__caption';
			counterEl = document.createElement( 'span' );
			counterEl.className = 'spg-lb__counter';

			box.append( imgEl, captionEl, counterEl );
			overlay.append( backdrop, prevBtn, nextBtn, closeBtn, box );
			document.body.appendChild( overlay );

			closeBtn.addEventListener( 'click', close );
			backdrop.addEventListener( 'click', close );
			prevBtn.addEventListener(  'click', function ( e ) { e.stopPropagation(); go( -1 ); } );
			nextBtn.addEventListener(  'click', function ( e ) { e.stopPropagation(); go(  1 ); } );
			document.addEventListener( 'keydown', function ( e ) {
				if ( ! overlay.classList.contains( 'spg-lb--open' ) ) return;
				if ( e.key === 'Escape'     ) close();
				if ( e.key === 'ArrowLeft'  ) go( -1 );
				if ( e.key === 'ArrowRight' ) go(  1 );
			} );
		}

		function open( imgs, idx ) {
			build();
			images  = imgs;
			current = idx;
			show( current );
			overlay.classList.add( 'spg-lb--open' );
			document.body.style.overflow = 'hidden';
		}

		function close() {
			overlay.classList.remove( 'spg-lb--open' );
			document.body.style.overflow = '';
		}

		function go( dir ) {
			current = ( current + dir + images.length ) % images.length;
			show( current );
		}

		function show( i ) {
			var item  = images[ i ];
			imgEl.classList.add( 'spg-lb__img--loading' );
			imgEl.onload = function () { imgEl.classList.remove( 'spg-lb__img--loading' ); };
			imgEl.src     = item.full || item.src;
			imgEl.alt     = item.alt  || '';

			captionEl.textContent  = item.caption || '';
			captionEl.style.display = item.caption ? '' : 'none';

			counterEl.textContent = ( i + 1 ) + ' / ' + images.length;

			var multi = images.length > 1;
			prevBtn.style.display = multi ? '' : 'none';
			nextBtn.style.display = multi ? '' : 'none';
		}

		return { open: open };
	})();

	/* ── Bind lightbox to a gallery ──────────────────────────── */
	function bindLightbox( gallery ) {
		var items    = gallery.querySelectorAll( '.spg-gallery-item' );
		var imgData  = Array.from( items ).map( function ( item ) {
			var img     = item.querySelector( 'img' );
			var link    = item.querySelector( '.spg-gallery-link' );
			var caption = item.querySelector( '.spg-caption' );
			return {
				src:     img  ? img.src  : '',
				full:    link ? link.href : ( img ? img.src : '' ),
				alt:     img  ? img.alt  : '',
				caption: caption ? caption.textContent.trim() : '',
			};
		} );

		items.forEach( function ( item, idx ) {
			var link = item.querySelector( '.spg-gallery-link' );
			if ( link ) {
				link.addEventListener( 'click', function ( e ) {
					e.preventDefault();
					lb.open( imgData, idx );
				} );
			}
		} );
	}

	/* ════════════════════════════════════════════════════════════
	   INIT — wire up every gallery on the page
	   ════════════════════════════════════════════════════════════ */
	function init() {
		document.querySelectorAll( '.spg-gallery' ).forEach( function ( gallery ) {
			var layout = gallery.dataset.layout;

			if ( layout === 'masonry'   ) initMasonry(   gallery );
			if ( layout === 'justified' ) initJustified( gallery );

			if ( gallery.dataset.lightbox === '1' ) bindLightbox( gallery );
		} );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}

})();
